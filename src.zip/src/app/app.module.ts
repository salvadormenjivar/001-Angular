import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AlumnoComponent } from 'src/alumnos/alumno/alumno.component';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,
    AlumnoComponent,
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
