import { Component } from "@angular/core";

@Component({
    selector:'app-alumno',
    templateUrl:'alumno.component.html',
})
export class AlumnoComponent{
    nombre:string='Armando Laínez';
    edad:number=25;
}